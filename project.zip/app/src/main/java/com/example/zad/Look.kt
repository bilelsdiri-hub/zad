package com.example.zad

import android.content.Context
import android.graphics.*
import android.media.MediaPlayer
import android.net.Uri
import android.os.SystemClock
import android.view.View
import java.io.File
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

val BACKGROUNDS = linkedMapOf(
    "night" to "ليل ونجوم", "water" to "أمواج هادئة", "geo" to "زخرفة إسلامية",
    "dawn" to "فجر", "image" to "صورة من هاتفي"
)
val FONT_NAMES = linkedMapOf("system" to "خط الهاتف", "amiri" to "النسخ (أميري)", "ruqaa" to "الرقعة", "kufi" to "الكوفي",
    "scheherazade" to "شهرزاد (نسخ)", "lateef" to "لطيف", "markazi" to "مركزي", "cairo" to "القاهرة", "tajawal" to "تجوّل", "almarai" to "المراعي", "nastaliq" to "النستعليق", "rakkas" to "رقّاص (عناوين)", "lalezar" to "لاله زار (عريض)", "katibeh" to "كاتبة", "mirza" to "ميرزا", "harmattan" to "هرمتان")
val TRACKS = linkedMapOf("water" to "خرير الماء", "qanun" to "القانون", "both" to "الماء والقانون")

fun bgFile(c: Context) = File(c.filesDir, "background.jpg")

fun saveBackground(c: Context, uri: Uri): Boolean = runCatching {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    c.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > 2000 || bounds.outHeight / sample > 3000) sample *= 2
    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
    val bmp = c.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }!!
    bgFile(c).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
}.isSuccess

fun fontExists(c: Context, name: String) = c.assets.list("fonts")?.contains("$name.ttf") == true

fun fontOf(c: Context, name: String): Typeface =
    if (name == "system") Typeface.DEFAULT
    else runCatching { Typeface.createFromAsset(c.assets, "fonts/$name.ttf") }.getOrDefault(Typeface.DEFAULT)

// خلفية متحركة مرسومة داخل التطبيقة
class Backdrop(c: Context, private val kind: String, private val dark: Boolean) : View(c) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val photo: Bitmap? =
        if (kind == "image" && bgFile(c).exists()) BitmapFactory.decodeFile(bgFile(c).path) else null

    private fun gradient(a: String, b: String) {
        paint.shader = LinearGradient(0f, 0f, 0f, height.toFloat(), Color.parseColor(a), Color.parseColor(b), Shader.TileMode.CLAMP)
        paint.style = Paint.Style.FILL
        paint.alpha = 255
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = (SystemClock.uptimeMillis() % 3_600_000L) / 1000f
        if (photo != null) {
            val scale = maxOf(w / photo.width, h / photo.height)
            val dw = photo.width * scale
            val dh = photo.height * scale
            canvas.drawBitmap(photo, null, RectF((w - dw) / 2, (h - dh) / 2, (w + dw) / 2, (h + dh) / 2), null)
            canvas.drawColor(if (dark) 0x99000000.toInt() else 0x55FFFFFF)
            return
        }
        when {
            kind == "dawn" -> if (dark) gradient("#1B1638", "#7A3F55") else gradient("#FDE7C7", "#BFD9E8")
            kind == "water" -> if (dark) gradient("#06232F", "#0B4A55") else gradient("#E8F7F5", "#A8DADC")
            else -> if (dark) gradient("#07111F", "#0F3B33") else gradient("#FBF6E9", "#D5EBDD")
        }
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
        val gold = Color.parseColor(if (dark) "#F2CC6B" else "#B8902F")
        paint.color = gold
        when (kind) {
            "water" -> for (k in 0..3) {
                path.reset()
                val base = h * (0.62f + k * 0.1f)
                path.moveTo(0f, h)
                var x = 0f
                while (x <= w + 20) {
                    path.lineTo(x, base + sin(x / w * 6.28f * 1.5f + t * (0.4f + k * 0.15f) + k) * h * 0.018f)
                    x += 20f
                }
                path.lineTo(w, h)
                path.close()
                paint.color = Color.parseColor("#2A9D8F")
                paint.alpha = 45
                canvas.drawPath(path, paint)
            }
            "geo" -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f
                paint.alpha = 55
                val step = w / 4
                val turn = t * 3f
                var row = 0
                while (row * step < h + step) {
                    for (col in 0..4) {
                        canvas.save()
                        canvas.translate(col * step, row * step)
                        canvas.rotate(if ((row + col) % 2 == 0) turn else -turn)
                        val r = step * 0.33f
                        canvas.drawRect(-r, -r, r, r, paint)
                        canvas.rotate(45f)
                        canvas.drawRect(-r, -r, r, r, paint)
                        canvas.restore()
                    }
                    row++
                }
                paint.style = Paint.Style.FILL
            }
            else -> {
                for (i in 0 until 70) {
                    val x = (i * 137.5f * 7) % w
                    val y = (i * 91.7f * 11 + t * (3 + i % 4)) % h
                    paint.alpha = (90 + 80 * sin(t * 1.5f + i)).toInt().coerceIn(10, 170)
                    canvas.drawCircle(x, y, 1.5f + i % 3, paint)
                }
                if (kind == "dawn") {
                    paint.alpha = 60
                    val r = min(w, h) * 0.18f
                    canvas.drawCircle(w / 2 + cos(t * 0.1f) * w * 0.2f, h * 0.85f, r, paint)
                }
            }
        }
        postInvalidateDelayed(50)
    }
}

object Music {
    private var player: MediaPlayer? = null
    private var playing = ""

    fun apply(c: Context) {
        val p = prefs(c)
        if (!p.getBoolean("music", false)) return stop()
        val track = p.getString("track", "water")!!
        if (track != playing) {
            stop()
            val res = when (track) {
                "qanun" -> R.raw.qanun
                "both" -> R.raw.both
                else -> R.raw.water
            }
            player = MediaPlayer.create(c.applicationContext, res)
            player?.isLooping = true
            playing = track
        }
        val v = p.getInt("volume", 40) / 100f
        player?.setVolume(v, v)
        player?.start()
    }

    fun pause() {
        player?.let { if (it.isPlaying) it.pause() }
    }

    private fun stop() {
        player?.release()
        player = null
        playing = ""
    }
}
