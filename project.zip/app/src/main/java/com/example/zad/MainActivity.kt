package com.example.zad

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.net.Uri
import android.speech.RecognizerIntent
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val PICK_IMAGE = 7
private const val SPEECH = 8
private val DAY_NAMES = listOf("الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")

// Activity من النظام، دون مكتبات واجهة إضافية
class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private var back: (() -> Unit)? = null
    private var current: () -> Unit = {}
    private var tab = 0
    private var silent = false
    private var monthShift = 0

    private val dark: Boolean
        get() = when (prefs(this).getString("mode", "auto")) {
            "dark" -> true
            "light" -> false
            else -> resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
        }
    private val ink get() = Color.parseColor(if (dark) "#F5EFE0" else "#17302A")
    private val glass get() = Color.parseColor(if (dark) "#B3142822" else "#D9FFFFFF")
    private val gold get() = Color.parseColor(if (dark) "#F2CC6B" else "#9A7420")
    private val green = Color.parseColor("#17765A")
    private val scale get() = prefs(this).getInt("size", 100) / 100f
    private val face get() = fontOf(this, prefs(this).getString("font", "amiri")!!)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Alarms.scheduleAll(this)
        if (!openFrom(intent)) home()
    }

    override fun onStart() {
        super.onStart()
        quiet(silent)
    }

    private fun quiet(on: Boolean) {
        silent = on
        if (on) Music.pause() else Music.apply(this)
    }

    override fun onStop() {
        super.onStop()
        Music.pause()
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        openFrom(i)
    }

    private fun openFrom(i: Intent): Boolean {
        if (i.getBooleanExtra("calendar", false)) {
            calendar()
            return true
        }
        val item = find(this, i.getStringExtra("item") ?: return false) ?: return false
        detail(item) { home() }
        return true
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val b = back
        if (b != null) b() else finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(request: Int, result: Int, data: Intent?) {
        super.onActivityResult(request, result, data)
        val uri = data?.data
        if (request == SPEECH && result == RESULT_OK) {
            val said = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (said != null) searchScreen(said)
        }
        if (request == PICK_IMAGE && result == RESULT_OK && uri != null) {
            if (saveBackground(this, uri)) prefs(this).edit().putString("bg", "image").apply()
            else toast("تعذر فتح الصورة")
            current()
        }
    }

    // ---------- عناصر الواجهة ----------

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun shape(color: Int, radius: Int = 22) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), Color.argb(90, 201, 162, 39))
    }

    private fun label(s: String, size: Float, color: Int = ink) = TextView(this).apply {
        text = s
        textSize = size * scale
        typeface = face
        setTextColor(color)
        textDirection = View.TEXT_DIRECTION_RTL
        setLineSpacing(0f, 1.2f)
    }

    private fun screen(title: String, prev: (() -> Unit)?): LinearLayout {
        back = prev
        quiet(false)
        window.statusBarColor = Color.parseColor("#0E4F3D")
        val frame = FrameLayout(this)
        frame.addView(Backdrop(this, prefs(this).getString("bg", "night")!!, dark), FrameLayout.LayoutParams(-1, -1))
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        bar.addView(round("☰") { menu() })
        bar.addView(label(title, 23f, gold).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(round(if (dark) "☀" else "☾") {
            prefs(this).edit().putString("mode", if (dark) "light" else "dark").apply()
            current()
        })
        page.addView(bar)
        frame.addView(page, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
        return page
    }

    private fun round(s: String, action: () -> Unit) = orb(s, 21f).apply {
        layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        setOnClickListener { action() }
    }

    private fun dialogTheme() =
        if (dark) android.R.style.Theme_DeviceDefault_Dialog_Alert else android.R.style.Theme_DeviceDefault_Light_Dialog_Alert

    private fun choose(title: String, names: List<String>, action: (Int) -> Unit) {
        AlertDialog.Builder(this, dialogTheme()).setTitle(title)
            .setItems(names.toTypedArray()) { _, i -> action(i) }.show()
    }

    private fun menu() {
        val entries = listOf<Pair<String, () -> Unit>>(
            "🏠  الرئيسية" to { home() },
            "🔍  البحث" to { searchScreen("") },
            "🎙  البحث الصوتي" to { listen() },
            "🗓  التقويم الهجري" to { monthShift = 0; calendar() },
            "🔔  الإشعارات" to { reminders() },
            "🔤  الخط وحجمه" to { fontScreen() },
            "🖼  الخلفية" to { backgrounds() },
            "🎵  الموسيقى" to { musicScreen() },
            "⚙  الإعدادات" to { settings() }
        )
        choose("القائمة", entries.map { it.first }) { entries[it].second() }
    }

    private fun page(title: String, prev: (() -> Unit)? = { home() }) {
        val page = screen(title, prev)
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(4), dp(16), dp(32))
        }
        page.addView(ScrollView(this).apply { addView(box) }, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun add(v: View): Unit =
        box.addView(v, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) })

    private fun card(s: String, size: Float = 19f, font: android.graphics.Typeface? = null): Unit = add(label(s, size).apply {
        if (font != null) typeface = font
        background = shape(glass)
        setPadding(dp(18), dp(16), dp(18), dp(16))
        setTextIsSelectable(true)
    })

    private fun button(s: String, selected: Boolean = false, action: () -> Unit): Unit =
        add(label(s, 18f, if (selected) Color.WHITE else ink).apply {
            gravity = Gravity.CENTER
            background = shape(if (selected) green else glass)
            setPadding(dp(14), dp(15), dp(14), dp(15))
            setOnClickListener { action() }
        })

    private fun seek(title: String, value: Int, from: Int, to: Int, done: (Int) -> Unit) {
        card(title, 17f)
        add(SeekBar(this).apply {
            max = to - from
            progress = value - from
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, user: Boolean) {}
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) = done(s.progress + from)
            })
        })
    }

    private fun listView(names: List<String>, aya: Boolean = false, open: (Int) -> Unit) = ListView(this).apply {
        divider = null
        dividerHeight = dp(10)
        setPadding(dp(16), dp(8), dp(16), dp(24))
        clipToPadding = false
        selector = GradientDrawable()
        adapter = object : BaseAdapter() {
            override fun getCount() = names.size
            override fun getItem(i: Int) = names[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, old: View?, parent: ViewGroup): View {
                val v = old as? TextView ?: label("", 19f).apply {
                    background = shape(glass)
                    setPadding(dp(18), dp(16), dp(18), dp(16))
                    maxLines = 3
                    if (aya) typeface = fontOf(this@MainActivity, "amiri")
                }
                v.text = names[i]
                return v
            }
        }
        setOnItemClickListener { _, _, i, _ -> open(i) }
    }

    // ---------- الرئيسية: صفحات أفقية ----------

    private fun home() {
        current = { home() }
        val page = screen("زاد اليوم", null)
        val today = hijri(this, System.currentTimeMillis())
        page.addView(label("${today.day} ${HIJRI_MONTHS[today.month - 1]} ${today.year} هـ", 17f).apply {
            gravity = Gravity.CENTER
            setOnClickListener { monthShift = 0; calendar() }
        })
        val tools = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(4))
        }
        listOf<Pair<String, () -> Unit>>(
            "🔍" to { searchScreen("") },
            "🎙" to { listen() },
            "🗓" to { monthShift = 0; calendar() },
            "🔔" to { reminders() },
            "⚙" to { settings() }
        ).forEach { (icon, action) ->
            tools.addView(round(icon, action), LinearLayout.LayoutParams(dp(54), dp(54)).apply { setMargins(dp(6), 0, dp(6), 0) })
        }
        page.addView(tools)
        page.addView(carousel(), LinearLayout.LayoutParams(-1, 0, 1f))
        page.addView(label("مرّر يمينًا ويسارًا، ثم انقر على البطاقة", 14f).apply {
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(20))
        })
    }

    // بطاقات متراكبة تدور في العمق، لكل قسم لون
    private fun carousel(): View {
        val titles = CATS.values.toList() + "المفضلة"
        val icons = listOf("📖", "🕌", "✨", "🤲", "🌱", "⭐")
        val colors = listOf("#1D9A6C" to "#0A4A38", "#2F7FC1" to "#12385E", "#8C5BC8" to "#3E2466",
            "#D9803A" to "#7A3A12", "#2AA7A0" to "#0D4F4C", "#C94F6D" to "#661F36")
        val pager = ViewPager2(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            clipChildren = false
            clipToPadding = false
            offscreenPageLimit = 3
        }
        pager.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = titles.size
            override fun getItemViewType(position: Int) = position
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                val holder = FrameLayout(this@MainActivity)
                holder.layoutParams = ViewGroup.LayoutParams(-1, -1)
                return object : RecyclerView.ViewHolder(holder) {}
            }

            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
                val frame = holder.itemView as FrameLayout
                frame.removeAllViews()
                val card = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                        Color.parseColor(colors[position].first), Color.parseColor(colors[position].second)
                    )).apply {
                        cornerRadius = dp(32).toFloat()
                        setStroke(dp(2), Color.argb(110, 255, 255, 255))
                    }
                    elevation = dp(14).toFloat()
                    setOnClickListener {
                        tab = position
                        browse()
                    }
                }
                card.addView(orb(icons[position], 62f), LinearLayout.LayoutParams(dp(150), dp(150)))
                card.addView(label(titles[position], 27f, Color.WHITE).apply {
                    gravity = Gravity.CENTER
                    setPadding(dp(12), dp(28), dp(12), 0)
                })
                frame.addView(card, FrameLayout.LayoutParams(-1, -1).apply { setMargins(dp(52), dp(24), dp(52), dp(24)) })
            }
        }
        pager.setPageTransformer { v, pos ->
            val away = kotlin.math.min(kotlin.math.abs(pos), 2f)
            v.cameraDistance = 12000f * resources.displayMetrics.density
            v.rotationY = pos * 38f
            v.scaleX = 1f - away * 0.14f
            v.scaleY = 1f - away * 0.14f
            // تقريب البطاقات الجانبية لتظهر فوق بعضها
            v.translationX = pos * v.width * 0.24f
            v.translationZ = -away * 20f
            v.alpha = 1f - away * 0.3f
        }
        pager.setCurrentItem(tab, false)
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                tab = position
            }
        })
        return pager
    }

    // أيقونة كروية لها عمق ولمعة
    private fun orb(icon: String, size: Float) = TextView(this).apply {
        text = icon
        textSize = size
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        background = glossy()
        elevation = dp(8).toFloat()
        setShadowLayer(dp(4).toFloat(), 0f, dp(3).toFloat(), 0x88000000.toInt())
    }

    private fun glossy() = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        gradientType = GradientDrawable.RADIAL_GRADIENT
        setGradientCenter(0.35f, 0.3f)
        gradientRadius = dp(60).toFloat()
        colors = intArrayOf(Color.parseColor("#7FD8B8"), Color.parseColor("#17765A"), Color.parseColor("#07382B"))
        setStroke(dp(1), Color.parseColor("#E8C46A"))
    }

    // ---------- البحث ----------

    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-TN")
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدّث عن الموضوع الذي تبحث عنه")
        try {
            startActivityForResult(intent, SPEECH)
        } catch (e: ActivityNotFoundException) {
            toast("التعرف الصوتي غير متوفر. ثبّت تطبيق Google أو فعّله")
        }
    }

    private fun searchScreen(query: String) {
        current = { searchScreen(query) }
        page("البحث")
        val input = EditText(this).apply {
            setText(query)
            hint = "اكتب كلمة أو موضوعًا"
            setTextColor(ink)
            setHintTextColor(Color.GRAY)
            textSize = 19f
            background = shape(glass)
            setPadding(dp(18), dp(14), dp(18), dp(14))
            setSingleLine(true)
        }
        add(input)
        button("🔍 بحث") { searchScreen(input.text.toString()) }
        button("🎙 بحث بالصوت") { listen() }
        if (query.isBlank()) return
        button("🌐 البحث في الإنترنت (يفتح المتصفح)") {
            val url = Uri.parse("https://www.google.com/search?q=" + Uri.encode("$query آيات وأحاديث"))
            runCatching { startActivity(Intent(Intent.ACTION_VIEW, url)) }
        }
        val status = label("جارٍ البحث...", 17f)
        add(status)
        val app = applicationContext
        val shown = box
        Thread {
            val result = runCatching { search(app, query) }
            runOnUiThread {
                if (shown !== box) return@runOnUiThread // غادر المستخدم الصفحة
                val found = result.getOrDefault(emptyList())
                status.text = if (found.isEmpty()) "لا نتائج في التطبيقة. جرّب كلمة أخرى" else "عدد النتائج المعروضة: ${found.size}"
                found.forEach { item ->
                    val kind = CATS[item.cat] ?: ""
                    button("[$kind]\n${item.text.take(140)}") { detail(item) { searchScreen(query) } }
                }
            }
        }.start()
    }

    private fun browse() {
        current = { browse() }
        val keys = CATS.keys.toList() + "fav"
        val titles = CATS.values.toList() + "المفضلة"
        val page = screen("زاد اليوم") { home() }
        val strip = LinearLayout(this).apply { setPadding(dp(10), dp(8), dp(10), dp(4)) }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(strip)
        }
        page.addView(scroller)
        val pager = ViewPager2(this).apply { layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val chips = titles.mapIndexed { i, name ->
            val chip = label(name, 16f).apply {
                setPadding(dp(16), dp(8), dp(16), dp(8))
                setOnClickListener { pager.currentItem = i }
            }
            strip.addView(chip, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(4), 0, dp(4), 0) })
            chip
        }
        fun mark(selected: Int) {
            chips.forEachIndexed { i, chip ->
                chip.background = shape(if (i == selected) green else glass)
                chip.setTextColor(if (i == selected) Color.WHITE else ink)
            }
            chips[selected].post {
                scroller.smoothScrollTo(chips[selected].left - (scroller.width - chips[selected].width) / 2, 0)
            }
        }
        pager.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = keys.size
            override fun getItemViewType(position: Int) = position
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                val holder = FrameLayout(this@MainActivity)
                holder.layoutParams = ViewGroup.LayoutParams(-1, -1)
                return object : RecyclerView.ViewHolder(holder) {}
            }

            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
                val frame = holder.itemView as FrameLayout
                frame.removeAllViews()
                frame.addView(section(keys[position]), FrameLayout.LayoutParams(-1, -1))
            }
        }
        page.addView(pager, LinearLayout.LayoutParams(-1, 0, 1f))
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                tab = position
                mark(position)
                quiet(keys[position] == "quran")
            }
        })
        pager.setCurrentItem(tab, false)
        mark(tab)
        quiet(keys[tab] == "quran")
    }

    private fun section(key: String): View {
        if (key == "quran") return quranIndex()
        val list = if (key == "fav")
            prefs(this).getStringSet("fav", emptySet())!!.sorted().mapNotNull { find(this, it) }
        else items(this, key)
        if (list.isEmpty()) return label("لا يوجد محتوى بعد", 18f).apply { gravity = Gravity.CENTER }
        return listView(list.map { it.text }) { i -> detail(list[i]) { browse() } }
    }

    // أول الصفحة: متابعة القراءة والأجزاء والأحزاب، ثم السور
    private fun quranIndex(): View {
        val p = prefs(this)
        val names = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        val last = p.getInt("last_s", 0)
        if (last > 0) {
            val at = p.getInt("last_a", 0)
            names.add("▶ متابعة القراءة: سورة ${SURAS[last - 1]}، الآية ${at + 1}")
            actions.add { suraScreen(last, at) }
        }
        if (marks(this, "juz").isNotEmpty()) {
            names.add("📖 الأجزاء")
            actions.add { parts(false) }
            names.add("📖 الأحزاب")
            actions.add { parts(true) }
        }
        SURAS.forEachIndexed { i, n ->
            names.add("${i + 1}. سورة $n")
            actions.add { suraScreen(i + 1) }
        }
        return listView(names) { actions[it]() }
    }

    private fun parts(hizb: Boolean) {
        current = { parts(hizb) }
        val all = marks(this, if (hizb) "quarters" else "juz")
        val starts = if (hizb) all.filterIndexed { i, _ -> i % 4 == 0 } else all
        val word = if (hizb) "الحزب" else "الجزء"
        val page = screen(if (hizb) "الأحزاب" else "الأجزاء") { browse() }
        val names = starts.mapIndexed { i, (s, a) -> "$word ${i + 1}\nيبدأ من سورة ${SURAS[s - 1]}، الآية $a" }
        page.addView(listView(names) { suraScreen(starts[it].first, starts[it].second - 1) },
            LinearLayout.LayoutParams(-1, 0, 1f))
        quiet(true)
    }

    // عنوان يظهر قبل الآية التي يبدأ عندها جزء أو حزب أو ربع
    private fun headers(s: Int): Map<Int, String> {
        val out = HashMap<Int, String>()
        marks(this, "quarters").forEachIndexed { i, (su, a) ->
            if (su == s) {
                val quarter = listOf("", "ربع ", "نصف ", "ثلاثة أرباع ")[i % 4]
                out[a] = "۞ ${quarter}الحزب ${i / 4 + 1}"
            }
        }
        marks(this, "juz").forEachIndexed { i, (su, a) ->
            if (su == s) out[a] = "الجزء ${i + 1}" + (out[a]?.let { " • $it" } ?: "")
        }
        return out
    }

    private fun suraScreen(s: Int, at: Int = 0) {
        current = { suraScreen(s, prefs(this).getInt("last_a", at)) }
        val list = sura(this, s)
        val head = headers(s)
        val page = screen("سورة ${SURAS[s - 1]}") { browse() }
        fun remember(i: Int) = prefs(this).edit().putInt("last_s", s).putInt("last_a", i).apply()
        remember(at)
        val names = list.mapIndexed { i, item -> (head[i + 1]?.let { "$it\n" } ?: "") + item.text }
        val view = listView(names, true) { i ->
            remember(i)
            detail(list[i]) { suraScreen(s, i) }
        }
        view.setSelection(at)
        view.setOnScrollListener(object : AbsListView.OnScrollListener {
            override fun onScrollStateChanged(v: AbsListView, state: Int) {
                if (state == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) remember(v.firstVisiblePosition)
            }

            override fun onScroll(v: AbsListView, first: Int, visible: Int, total: Int) {}
        })
        page.addView(view, LinearLayout.LayoutParams(-1, 0, 1f))
        quiet(true)
    }

    private fun detail(item: Item, prev: () -> Unit) {
        current = { detail(item, prev) }
        page(CATS[item.cat] ?: "", prev)
        // الآيات تُعرض دائمًا بخط النسخ حفاظًا على الرسم
        val isAya = item.id.startsWith("q:") || item.id.startsWith("dq:")
        card(item.text, 23f, if (isAya) fontOf(this, "amiri") else null)
        if (item.explain.isNotEmpty()) card(item.explain)
        card(item.source, 13f)
        val p = prefs(this)
        val fav = p.getStringSet("fav", emptySet())!!
        button(if (item.id in fav) "★ إزالة من المفضلة" else "☆ إضافة إلى المفضلة") {
            val new = if (item.id in fav) fav - item.id else fav + item.id
            p.edit().putStringSet("fav", new).apply()
            detail(item, prev)
        }
        quiet(item.cat == "quran" || item.id.startsWith("q:") || item.id.startsWith("dq:"))
        button("مشاركة") {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, "${item.text}\n\n${item.explain}\n\n${item.source}")
            startActivity(Intent.createChooser(send, "مشاركة"))
        }
    }

    // ---------- التقويم ----------

    private fun calendar() {
        current = { calendar() }
        page("التقويم الهجري")
        // نبحث عن أول يوم من الشهر المعروض
        var start = System.currentTimeMillis()
        start -= (hijri(this, start).day - 1) * DAY_MS
        repeat(kotlin.math.abs(monthShift)) {
            start += (if (monthShift > 0) 32 else -2) * DAY_MS
            start -= (hijri(this, start).day - 1) * DAY_MS
        }
        val first = hijri(this, start)
        card("${HIJRI_MONTHS[first.month - 1]} ${first.year} هـ", 22f)
        val grid = GridLayout(this).apply {
            columnCount = 7
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val cell = (resources.displayMetrics.widthPixels - dp(32)) / 7
        fun put(s: String, color: Int?) = grid.addView(TextView(this).apply {
            text = s
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(if (color == null) ink else Color.WHITE)
            background = shape(color ?: glass, 8)
        }, ViewGroup.LayoutParams(cell, dp(50)))
        DAY_NAMES.forEach { put(it.removePrefix("ال"), null) }
        val greg = java.util.Calendar.getInstance().apply { timeInMillis = start }
        repeat(greg.get(java.util.Calendar.DAY_OF_WEEK) - 1) { put("", null) }
        val format = SimpleDateFormat("d/M", Locale.US)
        val todayText = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
        val found = ArrayList<String>()
        var time = start
        while (true) {
            val d = hijri(this, time)
            if (d.month != first.month) break
            val events = eventOn(d)
            val isToday = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date(time)) == todayText
            put("${d.day}\n${format.format(Date(time))}",
                if (isToday) green else if (events.isNotEmpty()) Color.parseColor("#B8862B") else null)
            events.forEach { found.add("${d.day} ${HIJRI_MONTHS[d.month - 1]}: ${it.name}") }
            time += DAY_MS
        }
        add(grid)
        button("الشهر السابق") { monthShift--; calendar() }
        button("الشهر التالي") { monthShift++; calendar() }
        card(if (found.isEmpty()) "لا توجد مناسبات في هذا الشهر" else found.joinToString("\n"))
        button("إشعارات المناسبات") { eventSettings() }
        card("التقويم محسوب (أم القرى) وقد يختلف عن الرؤية المعتمدة في تونس. يمكنك تصحيحه من الإعدادات.", 14f)
    }

    private fun toggle(title: String, key: String, default: Boolean, after: () -> Unit): Unit = add(Switch(this).apply {
        text = title
        textSize = 17f * scale
        typeface = face
        setTextColor(ink)
        background = shape(glass)
        setPadding(dp(16), dp(12), dp(16), dp(12))
        isChecked = prefs(this@MainActivity).getBoolean(key, default)
        setOnCheckedChangeListener { _, on ->
            prefs(this@MainActivity).edit().putBoolean(key, on).apply()
            after()
        }
    })

    private fun eventSettings() {
        current = { eventSettings() }
        page("إشعارات المناسبات") { calendar() }
        card("إشعار واحد كل يوم، ابتداءً من ثلاثة أيام قبل المناسبة", 16f)
        toggle("تفعيل إشعارات المناسبات", "ev_on", true) { Alarms.scheduleEvents(this) }
        val p = prefs(this)
        val h = p.getInt("ev_h", 9)
        val m = p.getInt("ev_m", 0)
        button("وقت الإشعار: %02d:%02d".format(h, m)) {
            pickTime(h, m) { nh, nm ->
                p.edit().putInt("ev_h", nh).putInt("ev_m", nm).apply()
                Alarms.scheduleEvents(this)
                eventSettings()
            }
        }
        EVENTS.forEach { toggle(it.name, "ev_${it.key}", true) {} }
    }

    // ---------- الإشعارات ----------

    private fun pickTime(h: Int, m: Int, done: (Int, Int) -> Unit) {
        TimePickerDialog(this, dialogTheme(), { _, nh, nm -> done(nh, nm) }, h, m, true).show()
    }

    private fun daysText(days: Int) =
        if (days == ALL_DAYS) "كل يوم"
        else DAY_NAMES.filterIndexed { i, _ -> days and (1 shl i) != 0 }.joinToString("، ").ifEmpty { "لا يوم" }

    private fun reminders() {
        current = { reminders() }
        page("الإشعارات")
        Alarms.load(this).sortedBy { it.hour * 60 + it.min }.forEach { r ->
            button("%02d:%02d".format(r.hour, r.min) + "  •  ${CATS[r.cat]}\n${daysText(r.days)}" +
                if (r.on) "" else "  (متوقف)") { edit(r) }
        }
        button("➕ إضافة إشعار") {
            pickTime(9, 0) { h, m ->
                val r = Reminder(Alarms.newId(this), h, m, "dua", ALL_DAYS, true)
                Alarms.put(this, r)
                edit(r)
            }
        }
        button("إشعارات المناسبات الإسلامية") { eventSettings() }
    }

    private fun edit(r: Reminder) {
        current = { edit(r) }
        page("تعديل الإشعار") { reminders() }
        fun save(n: Reminder) {
            Alarms.put(this, n)
            edit(n)
        }
        button("الوقت: %02d:%02d".format(r.hour, r.min)) {
            pickTime(r.hour, r.min) { h, m -> save(r.copy(hour = h, min = m)) }
        }
        button("المحتوى: ${CATS[r.cat]}") {
            choose("المحتوى", CATS.values.toList()) { save(r.copy(cat = CATS.keys.toList()[it])) }
        }
        button("الأيام: ${daysText(r.days)}") {
            val checked = BooleanArray(7) { r.days and (1 shl it) != 0 }
            AlertDialog.Builder(this, dialogTheme()).setTitle("الأيام")
                .setMultiChoiceItems(DAY_NAMES.toTypedArray(), checked) { _, i, on -> checked[i] = on }
                .setPositiveButton("حفظ") { _, _ ->
                    save(r.copy(days = (0..6).sumOf { if (checked[it]) 1 shl it else 0 }))
                }.show()
        }
        button(if (r.on) "إيقاف" else "تفعيل", !r.on) { save(r.copy(on = !r.on)) }
        button("تجربة الآن") {
            val item = pick(this, r.cat, prefs(this).getInt("n_${r.cat}", 0))
            if (item != null) notify(this, r.id, CATS[item.cat] ?: "", item.text, item.id)
        }
        button("حذف") {
            Alarms.remove(this, r)
            reminders()
        }
    }

    // ---------- المظهر والصوت ----------

    private fun fontScreen() {
        current = { fontScreen() }
        page("الخط وحجمه")
        val p = prefs(this)
        card("نموذج لشكل الخط وحجمه داخل التطبيقة", 20f)
        seek("حجم الخط: ${p.getInt("size", 100)}%", p.getInt("size", 100), 80, 180) {
            p.edit().putInt("size", it).apply()
            fontScreen()
        }
        FONT_NAMES.filterKeys { it == "system" || fontExists(this, it) }.forEach { (key, name) ->
            button(name, p.getString("font", "amiri") == key) {
                p.edit().putString("font", key).apply()
                fontScreen()
            }
        }
    }

    private fun backgrounds() {
        current = { backgrounds() }
        page("الخلفية")
        val p = prefs(this)
        BACKGROUNDS.forEach { (key, name) ->
            button(name, p.getString("bg", "night") == key) {
                if (key == "image") {
                    val pickIntent = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
                    startActivityForResult(pickIntent, PICK_IMAGE)
                } else {
                    p.edit().putString("bg", key).apply()
                    backgrounds()
                }
            }
        }
    }

    private fun musicScreen() {
        current = { musicScreen() }
        page("الموسيقى")
        val p = prefs(this)
        toggle("تشغيل الصوت الهادئ", "music", false) { Music.apply(this) }
        TRACKS.forEach { (key, name) ->
            button(name, p.getString("track", "water") == key) {
                p.edit().putString("track", key).putBoolean("music", true).apply()
                Music.apply(this)
                musicScreen()
            }
        }
        seek("مستوى الصوت", p.getInt("volume", 40), 0, 100) {
            p.edit().putInt("volume", it).apply()
            Music.apply(this)
        }
    }

    private fun settings() {
        current = { settings() }
        page("الإعدادات")
        val p = prefs(this)
        val modes = linkedMapOf("auto" to "حسب الهاتف", "light" to "فاتح", "dark" to "ليلي")
        button("المظهر: ${modes[p.getString("mode", "auto")]}") {
            choose("المظهر", modes.values.toList()) {
                p.edit().putString("mode", modes.keys.toList()[it]).apply()
                settings()
            }
        }
        button("الخط وحجمه") { fontScreen() }
        button("الخلفية") { backgrounds() }
        button("الموسيقى") { musicScreen() }
        button("الإشعارات") { reminders() }
        button("تصحيح التاريخ الهجري: ${p.getInt("hoffset", 0)} يوم") {
            val values = listOf(-2, -1, 0, 1, 2)
            choose("تصحيح بالأيام", values.map { it.toString() }) {
                p.edit().putInt("hoffset", values[it]).apply()
                settings()
            }
        }
        button("⬇ تحديث الأدعية والمحتوى من الإنترنت") {
            toast("جارٍ التحديث...")
            val app = applicationContext
            Thread {
                val result = runCatching { updateExtra(app) }
                runOnUiThread {
                    val message = result.fold(
                        { "تم التحديث. عدد الإضافات: $it" },
                        { "تعذر التحديث. أرسل صورة لهذه الرسالة:\n\n${it.message}" }
                    )
                    if (!isFinishing) AlertDialog.Builder(this, dialogTheme()).setMessage(message)
                        .setPositiveButton("حسنًا", null).show()
                }
            }.start()
        }
        button("المصادر") { about() }
    }

    private fun about() {
        current = { about() }
        page("المصادر") { settings() }
        val meta = JSONObject(asset(this, "meta.json"))
        card("القرآن الكريم والتفسير الميسر: QuranEnc.com\nالنسخة: ${meta.optString("version")}")
        card("الأحاديث وشروحها: HadeethEnc.com\nالصحيح والحسن فقط. تصنيف القدسي والأدعية آلي وقد يخطئ.")
        card("الخطوط من Google Fonts (رخصة OFL)")
        card("حدود الأجزاء والأحزاب: Tanzil.net (رخصة CC BY)")
        card("تاريخ جلب المحتوى: ${meta.optString("date")}")
    }
}
