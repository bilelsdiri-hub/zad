package com.example.zad

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private var back: (() -> Unit)? = null
    private val night get() = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
    private val bg get() = Color.parseColor(if (night) "#0F1A16" else "#F6F1E4")
    private val card get() = Color.parseColor(if (night) "#1B2B24" else "#FFFFFF")
    private val ink get() = Color.parseColor(if (night) "#F1EBDD" else "#1E2B25")
    private val green = Color.parseColor("#146B4A")
    private val gold = Color.parseColor("#C9A227")

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        window.statusBarColor = green
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Alarms.scheduleAll(this)
        if (!openFrom(intent)) home()
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        openFrom(i)
    }

    private fun openFrom(i: Intent): Boolean {
        val item = find(this, i.getStringExtra("item") ?: return false) ?: return false
        detail(item) { home() }
        return true
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val b = back
        if (b != null) b() else finish()
    }

    private fun shape(color: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = 36f
        setStroke(3, gold)
    }

    private fun label(s: String, size: Float, color: Int = ink) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        textDirection = View.TEXT_DIRECTION_RTL
        setLineSpacing(0f, 1.25f)
    }

    private fun root(title: String, prev: (() -> Unit)?): LinearLayout {
        back = prev
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(bg)
        }
        page.addView(label(title, 24f, Color.WHITE).apply {
            setBackgroundColor(green)
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
        })
        setContentView(page)
        return page
    }

    private fun page(title: String, prev: (() -> Unit)?) {
        val page = root(title, prev)
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 24, 36, 48)
        }
        page.addView(ScrollView(this).apply { addView(box) })
    }

    private fun add(v: View) = box.addView(v, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 14, 0, 14) })

    private fun text(s: String, size: Float = 19f) = add(label(s, size).apply {
        background = shape(card)
        setPadding(44, 36, 44, 36)
        setTextIsSelectable(true)
    })

    private fun button(s: String, action: () -> Unit) = add(label(s, 19f).apply {
        gravity = Gravity.CENTER
        background = shape(card)
        setPadding(32, 40, 32, 40)
        setOnClickListener { action() }
    })

    // قائمة طويلة تُعرض بالتدريج
    private fun rows(title: String, names: List<String>, prev: () -> Unit, at: Int, open: (Int, Int) -> Unit) {
        val page = root(title, prev)
        val list = ListView(this)
        list.dividerHeight = 20
        list.divider = null
        list.dividerHeight = 20
        list.setPadding(36, 24, 36, 24)
        list.clipToPadding = false
        list.adapter = object : BaseAdapter() {
            override fun getCount() = names.size
            override fun getItem(i: Int) = names[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, old: View?, parent: ViewGroup): View {
                val v = old as? TextView ?: label("", 19f).apply {
                    background = shape(card)
                    setPadding(40, 36, 40, 36)
                    maxLines = 3
                }
                v.text = names[i]
                return v
            }
        }
        list.setSelection(at)
        list.setOnItemClickListener { _, _, i, _ -> open(i, list.firstVisiblePosition) }
        page.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        if (names.isEmpty()) page.addView(label("لا يوجد محتوى بعد", 19f).apply { setPadding(40, 40, 40, 40) }, 1)
    }

    private fun home() {
        page("زاد اليوم", null)
        button(CATS["quran"]!!) { suras(0) }
        CATS.filterKeys { it != "quran" }.forEach { (key, name) ->
            button(name) { itemList(name, items(this, key), { home() }, 0) }
        }
        button("المفضلة") {
            val fav = prefs(this).getStringSet("fav", emptySet())!!
            itemList("المفضلة", fav.sorted().mapNotNull { find(this, it) }, { home() }, 0)
        }
        button("أوقات الإشعارات") { settings() }
        button("المصادر") { about() }
    }

    private fun suras(at: Int) {
        rows("سور القرآن", SURAS.mapIndexed { i, n -> "${i + 1}. سورة $n" }, { home() }, at) { i, pos ->
            itemList("سورة ${SURAS[i]}", sura(this, i + 1), { suras(pos) }, 0)
        }
    }

    private fun itemList(title: String, list: List<Item>, prev: () -> Unit, at: Int) {
        rows(title, list.map { it.text }, prev, at) { i, pos ->
            detail(list[i]) { itemList(title, list, prev, pos) }
        }
    }

    private fun detail(item: Item, prev: () -> Unit) {
        page(CATS[item.cat] ?: "", prev)
        text(item.text, 23f)
        if (item.explain.isNotEmpty()) text(item.explain)
        text(item.source, 14f)
        val p = prefs(this)
        val fav = p.getStringSet("fav", emptySet())!!
        button(if (item.id in fav) "إزالة من المفضلة" else "إضافة إلى المفضلة") {
            val new = if (item.id in fav) fav - item.id else fav + item.id
            p.edit().putStringSet("fav", new).apply()
            detail(item, prev)
        }
        button("مشاركة") {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, "${item.text}\n\n${item.explain}\n\n${item.source}")
            startActivity(Intent.createChooser(send, "مشاركة"))
        }
    }

    private fun about() {
        page("المصادر", { home() })
        val meta = JSONObject(asset(this, "meta.json"))
        text("القرآن الكريم والتفسير الميسر: QuranEnc.com\nالنسخة: ${meta.optString("version")}")
        text("الأحاديث وشروحها: HadeethEnc.com\nالصحيح والحسن فقط. تصنيف القدسي والأدعية آلي وقد يخطئ.")
        text("تاريخ جلب المحتوى: ${meta.optString("date")}")
    }

    private fun settings() {
        page("أوقات الإشعارات", { home() })
        val p = prefs(this)
        SLOTS.forEach { s ->
            val h = p.getInt("h_${s.key}", s.hour)
            val m = p.getInt("m_${s.key}", 0)
            add(Switch(this).apply {
                text = s.title
                textSize = 19f
                setTextColor(ink)
                isChecked = p.getBoolean("on_${s.key}", true)
                setOnCheckedChangeListener { _, on ->
                    p.edit().putBoolean("on_${s.key}", on).apply()
                    Alarms.schedule(this@MainActivity, s)
                }
            })
            button("%02d:%02d".format(h, m)) {
                TimePickerDialog(this, { _, nh, nm ->
                    p.edit().putInt("h_${s.key}", nh).putInt("m_${s.key}", nm).apply()
                    Alarms.schedule(this, s)
                    settings()
                }, h, m, true).show()
            }
        }
    }
}
