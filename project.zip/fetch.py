# يجلب المحتوى من QuranEnc.com و HadeethEnc.com أثناء البناء، دون أي تعديل على النصوص
import json, os, re, sys, time, urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor

Q = "https://quranenc.com/api/v1"
H = "https://hadeethenc.com/api/v1"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "app/src/main/assets")

def get(url):
    for i in range(5):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "zad-app/2.0"})
            with urllib.request.urlopen(req, timeout=60) as r:
                return json.load(r)
        except Exception as e:
            if i == 4:
                raise RuntimeError(f"FAILED {url}: {e}")
            time.sleep(3 * (i + 1))

def save(name, data):
    path = os.path.join(OUT, name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False)

def plain(s):
    return re.sub("[ؐ-ًؚ-ٰٟۖ-ۭـ]", "", s)

QUDSI = re.compile(r"(فيما (يرويه|يروي|يحكي) عن (ربه|رب)|يرويه عن ربه|(صلى الله عليه وسلم|ﷺ)[^.]{0,20}(قال|يقول)\W{0,6}(قال|يقول) الله)")

def quran():
    total = 0
    for s in range(1, 115):
        rows = get(f"{Q}/translation/sura/arabic_moyassar/{s}")["result"]
        ayat = [{"a": int(r["aya"]), "t": r["arabic_text"], "e": r["translation"]} for r in rows]
        if not ayat or any(not x["t"] or not x["e"] for x in ayat):
            sys.exit(f"empty data in sura {s}")
        save(f"quran/{s}.json", ayat)
        total += len(ayat)
    print("ayat:", total)
    if total != 6236:
        sys.exit(f"unexpected number of ayat: {total}")

def hadiths():
    ids = []
    for c in get(f"{H}/categories/roots/?language=ar"):
        page = 1
        while True:
            r = get(f"{H}/hadeeths/list/?language=ar&category_id={c['id']}&page={page}&per_page=100")
            ids += [x["id"] for x in r["data"]]
            if page >= int(r["meta"]["last_page"]):
                break
            page += 1
    ids = list(dict.fromkeys(ids))
    print("hadith ids:", len(ids))
    with ThreadPoolExecutor(6) as pool:
        rows = list(pool.map(lambda i: get(f"{H}/hadeeths/one/?language=ar&id={i}"), ids))
    out = []
    for r in rows:
        grade = (r.get("grade") or "").strip()
        # الصحيح والحسن فقط
        if not plain(grade).startswith(("صحيح", "حسن")):
            continue
        text = r["hadeeth"]
        p = plain(text)
        out.append({
            "id": f"h:{r['id']}",
            "cat": "qudsi" if QUDSI.search(p) else "hadith",
            "dua": "اللهم" in p,
            "text": text,
            "explain": r.get("explanation") or "",
            "source": f"{r.get('attribution') or ''} - {grade}\nالمصدر: HadeethEnc.com",
        })
    if len(out) < 100:
        sys.exit(f"too few hadiths: {len(out)}")
    save("hadith.json", out)
    print("hadiths:", len(out), "qudsi:", sum(x["cat"] == "qudsi" for x in out), "dua:", sum(x["dua"] for x in out))

def version():
    for t in get(f"{Q}/translations/list/ar")["translations"]:
        if t["key"] == "arabic_moyassar":
            return str(t.get("version", ""))
    return ""

FONTS = {
    "scheherazade": "scheherazadenew/ScheherazadeNew-Regular.ttf",
    "lateef": "lateef/Lateef-Regular.ttf",
    "markazi": "markazitext/MarkaziText%5Bwght%5D.ttf",
    "cairo": "cairo/Cairo%5Bslnt%2Cwght%5D.ttf",
    "tajawal": "tajawal/Tajawal-Regular.ttf",
    "almarai": "almarai/Almarai-Regular.ttf",
    "nastaliq": "notonastaliqurdu/NotoNastaliqUrdu%5Bwght%5D.ttf",
    "rakkas": "rakkas/Rakkas-Regular.ttf",
    "lalezar": "lalezar/Lalezar-Regular.ttf",
    "katibeh": "katibeh/Katibeh-Regular.ttf",
    "mirza": "mirza/Mirza-Regular.ttf",
    "harmattan": "harmattan/Harmattan-Regular.ttf",
    "amiri": "amiri/Amiri-Regular.ttf",
    "ruqaa": "arefruqaa/ArefRuqaa-Regular.ttf",
    "kufi": "reemkufi/ReemKufi%5Bwght%5D.ttf",
}

def fonts():
    # خطوط مفتوحة من مستودع Google Fonts، وإذا تعذر أحدها تستعمل التطبيقة خط الهاتف
    os.makedirs(os.path.join(OUT, "fonts"), exist_ok=True)
    for name, path in FONTS.items():
        target = os.path.join(OUT, "fonts", name + ".ttf")
        if os.path.exists(target):
            continue
        try:
            urllib.request.urlretrieve("https://raw.githubusercontent.com/google/fonts/main/ofl/" + path, target)
        except Exception as e:
            print("WARNING font", name, e)

def quran_marks():
    # حدود الأجزاء والأحزاب من Tanzil، وإذا تعذرت تُخفى من التطبيقة
    try:
        url = "https://tanzil.net/res/text/metadata/quran-data.xml"
        req = urllib.request.Request(url, headers={"User-Agent": "zad-app/4.0"})
        with urllib.request.urlopen(req, timeout=60) as r:
            root = ET.fromstring(r.read())
        out = {}
        for key, tag, count in (("juz", "juz", 30), ("quarters", "quarter", 240)):
            out[key] = [[int(e.get("sura")), int(e.get("aya"))] for e in root.iter(tag)]
            if len(out[key]) != count:
                raise ValueError(f"{tag}: {len(out[key])}")
        save("marks.json", out)
    except Exception as e:
        print("WARNING marks", e)

if __name__ == "__main__":
    fonts()
    os.makedirs(OUT, exist_ok=True)
    quran_marks()
    if os.path.exists(os.path.join(OUT, "meta.json")):
        sys.exit(0)
    quran()
    hadiths()
    save("meta.json", {"version": version(), "date": time.strftime("%Y-%m-%d")})
