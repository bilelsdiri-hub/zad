package com.example.zad

import android.app.*
import android.content.*
import java.util.Calendar

object Alarms {
    fun schedule(c: Context, s: Slot) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            c, SLOTS.indexOf(s), Intent(c, AlarmReceiver::class.java).putExtra("slot", s.key),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
        val p = prefs(c)
        if (!p.getBoolean("on_${s.key}", true)) return
        val t = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, p.getInt("h_${s.key}", s.hour))
            set(Calendar.MINUTE, p.getInt("m_${s.key}", 0))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.timeInMillis, pi)
    }

    fun scheduleAll(c: Context) = SLOTS.forEach { schedule(c, it) }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val s = SLOTS.find { it.key == intent.getStringExtra("slot") } ?: return
        Alarms.schedule(c, s)
        val p = prefs(c)
        val n = p.getInt("n_${s.key}", 0)
        val item = pick(c, s, n) ?: return
        p.edit().putInt("n_${s.key}", n + 1).apply()
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("daily", "التذكير اليومي", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(
            c, SLOTS.indexOf(s),
            Intent(c, MainActivity::class.java).putExtra("item", item.id)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        nm.notify(SLOTS.indexOf(s), Notification.Builder(c, "daily")
            .setSmallIcon(R.drawable.ic_note)
            .setContentTitle(CATS[item.cat])
            .setContentText(item.text)
            .setStyle(Notification.BigTextStyle().bigText(item.text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build())
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) = Alarms.scheduleAll(c)
}
