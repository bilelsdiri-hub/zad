package com.example.zad

import android.content.Context
import android.icu.util.IslamicCalendar

class Event(val key: String, val name: String, val month: Int, val day: Int)

// الأشهر من 1 إلى 12. بعض هذه التواريخ هو المشهور مع وجود خلاف فيه
val EVENTS = listOf(
    Event("newyear", "رأس السنة الهجرية", 1, 1),
    Event("tasua", "يوم تاسوعاء", 1, 9),
    Event("ashura", "يوم عاشوراء", 1, 10),
    Event("mawlid", "المولد النبوي الشريف", 3, 12),
    Event("isra", "ذكرى الإسراء والمعراج", 7, 27),
    Event("shaban", "ليلة النصف من شعبان", 8, 15),
    Event("ramadan", "أول رمضان", 9, 1),
    Event("qadr", "ليلة السابع والعشرين من رمضان", 9, 27),
    Event("fitr", "عيد الفطر", 10, 1),
    Event("hijja", "أول ذي الحجة", 12, 1),
    Event("arafa", "يوم عرفة", 12, 9),
    Event("adha", "عيد الأضحى", 12, 10)
)

val HIJRI_MONTHS = listOf("محرم", "صفر", "ربيع الأول", "ربيع الآخر", "جمادى الأولى", "جمادى الآخرة",
    "رجب", "شعبان", "رمضان", "شوال", "ذو القعدة", "ذو الحجة")

const val DAY_MS = 86_400_000L

class HDate(val year: Int, val month: Int, val day: Int)

// التاريخ الهجري (أم القرى) مع تصحيح يدوي حسب الرؤية المحلية
fun hijri(c: Context, time: Long): HDate {
    val cal = IslamicCalendar()
    cal.calculationType = IslamicCalendar.CalculationType.ISLAMIC_UMALQURA
    cal.timeInMillis = time + prefs(c).getInt("hoffset", 0) * DAY_MS
    return HDate(cal.get(android.icu.util.Calendar.YEAR), cal.get(android.icu.util.Calendar.MONTH) + 1,
        cal.get(android.icu.util.Calendar.DAY_OF_MONTH))
}

fun eventOn(d: HDate) = EVENTS.filter { it.month == d.month && it.day == d.day }

// المناسبات القادمة خلال عدد من الأيام: (المناسبة، بعد كم يوم)
fun upcoming(c: Context, days: Int): List<Pair<Event, Int>> {
    val now = System.currentTimeMillis()
    return (0..days).flatMap { i -> eventOn(hijri(c, now + i * DAY_MS)).map { it to i } }
}
