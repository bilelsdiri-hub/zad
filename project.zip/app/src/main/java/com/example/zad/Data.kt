package com.example.zad

import android.content.Context
import org.json.JSONArray

data class Item(val id: String, val cat: String, val text: String, val explain: String, val source: String)

class Slot(val key: String, val title: String, val hour: Int, val cats: List<String>)

val SLOTS = listOf(
    Slot("morning", "آية وتفسيرها", 7, listOf("quran")),
    Slot("noon", "حديث وشرحه", 13, listOf("hadith", "qudsi")),
    Slot("evening", "دعاء أو قول تحفيزي", 20, listOf("dua", "motiv"))
)

val CATS = linkedMapOf(
    "quran" to "القرآن والتفسير", "hadith" to "أحاديث نبوية", "qudsi" to "أحاديث قدسية",
    "dua" to "أدعية", "motiv" to "أقوال تحفيزية"
)

fun prefs(c: Context) = c.getSharedPreferences("zad", Context.MODE_PRIVATE)

fun loadItems(c: Context): List<Item> {
    val a = JSONArray(c.assets.open("content.json").bufferedReader().use { it.readText() })
    return (0 until a.length()).map {
        val o = a.getJSONObject(it)
        Item(o.getString("id"), o.getString("cat"), o.getString("text"), o.optString("explain"), o.optString("source"))
    }
}
