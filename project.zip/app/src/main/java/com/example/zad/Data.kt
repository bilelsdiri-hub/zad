package com.example.zad

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class Item(val id: String, val cat: String, val text: String, val explain: String, val source: String)

val CATS = linkedMapOf(
    "quran" to "القرآن والتفسير", "hadith" to "أحاديث نبوية", "qudsi" to "أحاديث قدسية",
    "dua" to "أدعية", "motiv" to "أقوال تحفيزية"
)

val SURAS = ("الفاتحة،البقرة،آل عمران،النساء،المائدة،الأنعام،الأعراف،الأنفال،التوبة،يونس،هود،يوسف،الرعد،إبراهيم،الحجر،النحل،الإسراء،الكهف،مريم،طه،" +
    "الأنبياء،الحج،المؤمنون،النور،الفرقان،الشعراء،النمل،القصص،العنكبوت،الروم،لقمان،السجدة،الأحزاب،سبأ،فاطر،يس،الصافات،ص،الزمر،غافر،" +
    "فصلت،الشورى،الزخرف،الدخان،الجاثية،الأحقاف،محمد،الفتح،الحجرات،ق،الذاريات،الطور،النجم،القمر،الرحمن،الواقعة،الحديد،المجادلة،الحشر،الممتحنة،" +
    "الصف،الجمعة،المنافقون،التغابن،الطلاق،التحريم،الملك،القلم،الحاقة،المعارج،نوح،الجن،المزمل،المدثر،القيامة،الإنسان،المرسلات،النبأ،النازعات،عبس،" +
    "التكوير،الانفطار،المطففين،الانشقاق،البروج،الطارق،الأعلى،الغاشية،الفجر،البلد،الشمس،الليل،الضحى،الشرح،التين،العلق،القدر،البينة،الزلزلة،العاديات،" +
    "القارعة،التكاثر،العصر،الهمزة،الفيل،قريش،الماعون،الكوثر،الكافرون،النصر،المسد،الإخلاص،الفلق،الناس").split("،")

// آيات فيها أدعية: (السورة، الآية)
val QURAN_DUAS = listOf(2 to 201, 2 to 286, 3 to 8, 3 to 193, 14 to 40, 14 to 41, 17 to 24, 20 to 25, 20 to 114,
    23 to 118, 25 to 74, 59 to 10)

fun prefs(c: Context) = c.getSharedPreferences("zad", Context.MODE_PRIVATE)

fun asset(c: Context, name: String) = c.assets.open(name).bufferedReader().use { it.readText() }

private val suraCache = HashMap<Int, List<Item>>()
private var otherCache: List<Item>? = null

fun sura(c: Context, s: Int): List<Item> = suraCache.getOrPut(s) {
    val a = JSONArray(asset(c, "quran/$s.json"))
    val version = JSONObject(asset(c, "meta.json")).optString("version")
    (0 until a.length()).map {
        val o = a.getJSONObject(it)
        val n = o.getInt("a")
        Item("q:$s:$n", "quran", o.getString("t") + "\n﴿سورة ${SURAS[s - 1]}: $n﴾", o.getString("e"),
            "التفسير الميسر - المصدر: QuranEnc.com - النسخة $version")
    }
}

const val EXTRA_URL = "https://raw.githubusercontent.com/bilelsdiri-hub/zad/main/extra.json"

private fun others(c: Context): List<Item> = otherCache ?: run {
    val out = ArrayList<Item>()
    for (file in listOf("hadith.json", "motiv.json")) addAll(out, JSONArray(asset(c, file)))
    val extra = File(c.filesDir, "extra.json")
    if (extra.exists()) runCatching { addAll(out, JSONArray(extra.readText())) }
    otherCache = out
    out
}

private fun addAll(out: ArrayList<Item>, a: JSONArray) {
    for (i in 0 until a.length()) {
        val o = a.getJSONObject(i)
        val text = o.getString("text")
        val item = Item(o.optString("id", "x:" + text.hashCode()), o.getString("cat"), text,
            o.optString("explain"), o.optString("source"))
        out.add(item)
        if (o.optBoolean("dua")) out.add(item.copy(id = "d" + item.id, cat = "dua"))
    }
}

// ينزّل الإضافات من المستودع، ويعيد عددها. يُستدعى خارج الخيط الرئيسي
fun updateExtra(c: Context): Int {
    val con = URL(EXTRA_URL).openConnection() as HttpURLConnection
    con.connectTimeout = 15000
    con.readTimeout = 15000
    con.useCaches = false
    val body = try {
        con.inputStream.bufferedReader().use { it.readText() }
    } finally {
        con.disconnect()
    }
    val a = JSONArray(body)
    addAll(ArrayList(), a) // تحقق من الصيغة قبل الحفظ
    File(c.filesDir, "extra.json").writeText(body)
    otherCache = null
    return a.length()
}

fun items(c: Context, cat: String): List<Item> = when (cat) {
    "dua" -> QURAN_DUAS.mapNotNull { (s, a) -> sura(c, s).getOrNull(a - 1)?.copy(id = "dq:$s:$a", cat = "dua") } +
        others(c).filter { it.cat == "dua" }
    else -> others(c).filter { it.cat == cat }
}

fun find(c: Context, id: String): Item? {
    val p = id.split(":")
    return when (p[0]) {
        "q" -> sura(c, p[1].toInt()).getOrNull(p[2].toInt() - 1)
        "dq" -> items(c, "dua").find { it.id == id }
        else -> others(c).find { it.id == id }
    }
}

// العنصر رقم n في إشعارات هذا القسم
fun pick(c: Context, cat: String, n: Int): Item? {
    if (cat == "quran") {
        var left = n % 6236
        for (i in 1..114) {
            val list = sura(c, i)
            if (left < list.size) return list[left]
            left -= list.size
        }
        return null
    }
    val list = items(c, cat)
    return if (list.isEmpty()) null else list[n % list.size]
}
