package com.example.zad

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Item(val id: String, val cat: String, val text: String, val explain: String, val source: String)

class Slot(val key: String, val title: String, val hour: Int, val cats: List<String>)

val SLOTS = listOf(
    Slot("morning", "آية وتفسيرها", 7, listOf("quran")),
    Slot("noon", "حديث وشرحه", 13, listOf("hadith", "qudsi")),
    Slot("evening", "دعاء أو قول تحفيزي", 20, listOf("dua", "motiv"))
)

val CATS = linkedMapOf(
    "quran" to "القرآن والتفسير", "hadith" to "أحاديث نبوية", "qudsi" to "أحاديث قدسية",
    "dua" to "أدعية", "motiv" to "أقوال تحفيزية"
)

val SURAS = ("الفاتحة،البقرة،آل عمران،النساء،المائدة،الأنعام،الأعراف،الأنفال،التوبة،يونس،هود،يوسف،الرعد،إبراهيم،الحجر،النحل،الإسراء،الكهف،مريم،طه،" +
    "الأنبياء،الحج،المؤمنون،النور،الفرقان،الشعراء،النمل،القصص،العنكبوت،الروم،لقمان،السجدة،الأحزاب،سبأ،فاطر،يس،الصافات،ص،الزمر،غافر،" +
    "فصلت،الشورى،الزخرف،الدخان،الجاثية،الأحقاف،محمد،الفتح،الحجرات،ق،الذاريات،الطور،النجم،القمر،الرحمن،الواقعة،الحديد،المجادلة،الحشر،الممتحنة،" +
    "الصف،الجمعة،المنافقون،التغابن،الطلاق،التحريم،الملك،القلم،الحاقة،المعارج،نوح،الجن،المزمل،المدثر،القيامة،الإنسان،المرسلات،النبأ،النازعات،عبس،" +
    "التكوير،الانفطار،المطففين،الانشقاق،البروج،الطارق،الأعلى،الغاشية،الفجر،البلد،الشمس،الليل،الضحى،الشرح،التين،العلق،القدر،البينة،الزلزلة،العاديات،" +
    "القارعة،التكاثر،العصر،الهمزة،الفيل،قريش،الماعون،الكوثر،الكافرون،النصر،المسد،الإخلاص،الفلق،الناس").split("،")

// آيات فيها أدعية: (السورة، الآية)
val QURAN_DUAS = listOf(2 to 201, 2 to 286, 3 to 8, 3 to 193, 14 to 40, 14 to 41, 17 to 24, 20 to 25, 20 to 114,
    23 to 118, 25 to 74, 59 to 10)

fun prefs(c: Context) = c.getSharedPreferences("zad", Context.MODE_PRIVATE)

fun asset(c: Context, name: String) = c.assets.open(name).bufferedReader().use { it.readText() }

private val suraCache = HashMap<Int, List<Item>>()
private var otherCache: List<Item>? = null

fun sura(c: Context, s: Int): List<Item> = suraCache.getOrPut(s) {
    val a = JSONArray(asset(c, "quran/$s.json"))
    val version = JSONObject(asset(c, "meta.json")).optString("version")
    (0 until a.length()).map {
        val o = a.getJSONObject(it)
        val n = o.getInt("a")
        Item("q:$s:$n", "quran", o.getString("t") + "\n﴿سورة ${SURAS[s - 1]}: $n﴾", o.getString("e"),
            "التفسير الميسر - المصدر: QuranEnc.com - النسخة $version")
    }
}

private fun others(c: Context): List<Item> = otherCache ?: run {
    val out = ArrayList<Item>()
    for (file in listOf("hadith.json", "motiv.json")) {
        val a = JSONArray(asset(c, file))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val item = Item(o.getString("id"), o.getString("cat"), o.getString("text"), o.optString("explain"), o.optString("source"))
            out.add(item)
            if (o.optBoolean("dua")) out.add(item.copy(id = "d" + item.id, cat = "dua"))
        }
    }
    otherCache = out
    out
}

fun items(c: Context, cat: String): List<Item> = when (cat) {
    "dua" -> QURAN_DUAS.mapNotNull { (s, a) -> sura(c, s).getOrNull(a - 1)?.copy(id = "dq:$s:$a", cat = "dua") } +
        others(c).filter { it.cat == "dua" }
    else -> others(c).filter { it.cat == cat }
}

fun find(c: Context, id: String): Item? {
    val p = id.split(":")
    return when (p[0]) {
        "q" -> sura(c, p[1].toInt()).getOrNull(p[2].toInt() - 1)
        "dq" -> items(c, "dua").find { it.id == id }
        else -> others(c).find { it.id == id }
    }
}

// العنصر رقم n في إشعارات هذا الوقت
fun pick(c: Context, s: Slot, n: Int): Item? {
    if (s.cats == listOf("quran")) {
        var left = n % 6236
        for (i in 1..114) {
            val list = sura(c, i)
            if (left < list.size) return list[left]
            left -= list.size
        }
        return null
    }
    // بالتناوب بين القسمين
    val first = s.cats[n % s.cats.size]
    val list = items(c, first).ifEmpty { s.cats.flatMap { items(c, it) } }
    return if (list.isEmpty()) null else list[(n / s.cats.size) % list.size]
}
