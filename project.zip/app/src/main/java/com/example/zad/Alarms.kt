package com.example.zad

import android.app.*
import android.content.*
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

// days: سبعة بتات، البت 0 هو الأحد
data class Reminder(val id: Int, val hour: Int, val min: Int, val cat: String, val days: Int, val on: Boolean)

const val ALL_DAYS = 127
const val EVENTS_CODE = 50

object Alarms {
    fun load(c: Context): List<Reminder> {
        val p = prefs(c)
        val saved = p.getString("reminders", null)
        if (saved == null) {
            // أول تشغيل: نحافظ على أوقات النسخة السابقة
            val first = listOf(Triple("morning", 7, "quran"), Triple("noon", 13, "hadith"), Triple("evening", 20, "dua"))
                .mapIndexed { i, (k, h, cat) ->
                    Reminder(100 + i, p.getInt("h_$k", h), p.getInt("m_$k", 0), cat, ALL_DAYS, p.getBoolean("on_$k", true))
                }
            store(c, first)
            return first
        }
        val a = JSONArray(saved)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Reminder(o.getInt("id"), o.getInt("h"), o.getInt("m"), o.getString("cat"), o.getInt("days"), o.getBoolean("on"))
        }
    }

    private fun store(c: Context, list: List<Reminder>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("h", it.hour).put("m", it.min).put("cat", it.cat)
                .put("days", it.days).put("on", it.on))
        }
        prefs(c).edit().putString("reminders", a.toString()).apply()
    }

    fun put(c: Context, r: Reminder) {
        store(c, load(c).filter { it.id != r.id } + r)
        schedule(c, r)
    }

    fun remove(c: Context, r: Reminder) {
        store(c, load(c).filter { it.id != r.id })
        c.getSystemService(AlarmManager::class.java).cancel(pending(c, r.id))
    }

    fun newId(c: Context) = (load(c).maxOfOrNull { it.id } ?: 99) + 1

    private fun pending(c: Context, id: Int) = PendingIntent.getBroadcast(
        c, id, Intent(c, AlarmReceiver::class.java).putExtra("rid", id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun set(c: Context, id: Int, hour: Int, min: Int, on: Boolean) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = pending(c, id)
        am.cancel(pi)
        if (!on) return
        val t = Calendar.getInstance()
        t.set(Calendar.HOUR_OF_DAY, hour)
        t.set(Calendar.MINUTE, min)
        t.set(Calendar.SECOND, 0)
        t.set(Calendar.MILLISECOND, 0)
        if (t.timeInMillis <= System.currentTimeMillis()) t.add(Calendar.DAY_OF_YEAR, 1)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.timeInMillis, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.timeInMillis, pi)
    }

    fun schedule(c: Context, r: Reminder) = set(c, r.id, r.hour, r.min, r.on && r.days != 0)

    fun scheduleEvents(c: Context) {
        val p = prefs(c)
        set(c, EVENTS_CODE, p.getInt("ev_h", 9), p.getInt("ev_m", 0), p.getBoolean("ev_on", true))
    }

    fun scheduleAll(c: Context) {
        load(c).forEach { schedule(c, it) }
        scheduleEvents(c)
    }
}

fun notify(c: Context, id: Int, title: String, text: String, itemId: String?) {
    val nm = c.getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("daily", "التذكير اليومي", NotificationManager.IMPORTANCE_DEFAULT))
    val intent = Intent(c, MainActivity::class.java)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
    if (itemId != null) intent.putExtra("item", itemId) else intent.putExtra("calendar", true)
    val open = PendingIntent.getActivity(c, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    nm.notify(id, Notification.Builder(c, "daily")
        .setSmallIcon(R.drawable.ic_note)
        .setContentTitle(title)
        .setContentText(text)
        .setStyle(Notification.BigTextStyle().bigText(text))
        .setContentIntent(open)
        .setAutoCancel(true)
        .build())
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) {
        val id = intent.getIntExtra("rid", -1)
        val p = prefs(c)
        if (id == EVENTS_CODE) {
            Alarms.scheduleEvents(c)
            // مرة كل يوم من ثلاثة أيام قبل المناسبة إلى يومها
            upcoming(c, 3).filter { p.getBoolean("ev_${it.first.key}", true) }.forEach { (e, left) ->
                val text = when (left) {
                    0 -> "اليوم"
                    1 -> "غدًا"
                    2 -> "بعد يومين"
                    else -> "بعد ثلاثة أيام"
                }
                notify(c, 500 + EVENTS.indexOf(e), e.name, text, null)
            }
            return
        }
        val r = Alarms.load(c).find { it.id == id } ?: return
        Alarms.schedule(c, r)
        val today = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1
        if (r.days and (1 shl today) == 0) return
        val n = p.getInt("n_${r.cat}", 0)
        val item = pick(c, r.cat, n) ?: return
        p.edit().putInt("n_${r.cat}", n + 1).apply()
        notify(c, r.id, CATS[item.cat] ?: "زاد اليوم", item.text, item.id)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent) = Alarms.scheduleAll(c)
}
