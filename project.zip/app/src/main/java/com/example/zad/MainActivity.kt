package com.example.zad

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private var back: (() -> Unit)? = null

    override fun onCreate(state: Bundle?) {
        super.onCreate(state)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        Alarms.scheduleAll(this)
        if (!openFrom(intent)) home()
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        openFrom(i)
    }

    private fun openFrom(i: Intent): Boolean {
        val item = loadItems(this).find { it.id == i.getStringExtra("item") } ?: return false
        detail(item) { home() }
        return true
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val b = back
        if (b != null) b() else finish()
    }

    private fun page(title: String, prev: (() -> Unit)?) {
        back = prev
        box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(40, 60, 40, 60)
        }
        setContentView(ScrollView(this).apply { addView(box) })
        text(title, 26f)
    }

    private fun text(s: String, size: Float = 18f) = box.addView(TextView(this).apply {
        text = s
        textSize = size
        textDirection = View.TEXT_DIRECTION_RTL
        setPadding(0, 20, 0, 20)
        setTextIsSelectable(true)
    })

    private fun button(s: String, action: () -> Unit) = box.addView(Button(this).apply {
        text = s
        textSize = 17f
        setOnClickListener { action() }
    })

    private fun home() {
        page("زاد اليوم", null)
        CATS.forEach { (key, name) -> button(name) { list(name) { it.cat == key } } }
        button("المفضلة") {
            val fav = prefs(this).getStringSet("fav", emptySet())!!
            list("المفضلة") { it.id in fav }
        }
        button("أوقات الإشعارات") { settings() }
    }

    private fun list(title: String, filter: (Item) -> Boolean) {
        page(title, { home() })
        val items = loadItems(this).filter(filter)
        if (items.isEmpty()) text("لا يوجد محتوى بعد")
        items.forEach { item -> button(item.text.take(60)) { detail(item) { list(title, filter) } } }
    }

    private fun detail(item: Item, prev: () -> Unit) {
        page(CATS[item.cat] ?: "", prev)
        text(item.text, 22f)
        if (item.explain.isNotEmpty()) text(item.explain)
        text(item.source, 14f)
        val p = prefs(this)
        val fav = p.getStringSet("fav", emptySet())!!
        button(if (item.id in fav) "إزالة من المفضلة" else "إضافة إلى المفضلة") {
            val new = if (item.id in fav) fav - item.id else fav + item.id
            p.edit().putStringSet("fav", new).apply()
            detail(item, prev)
        }
        button("مشاركة") {
            val send = Intent(Intent.ACTION_SEND).setType("text/plain")
                .putExtra(Intent.EXTRA_TEXT, "${item.text}\n\n${item.explain}\n\n${item.source}")
            startActivity(Intent.createChooser(send, "مشاركة"))
        }
    }

    private fun settings() {
        page("أوقات الإشعارات", { home() })
        val p = prefs(this)
        SLOTS.forEach { s ->
            val h = p.getInt("h_${s.key}", s.hour)
            val m = p.getInt("m_${s.key}", 0)
            box.addView(Switch(this).apply {
                text = s.title
                textSize = 18f
                isChecked = p.getBoolean("on_${s.key}", true)
                setOnCheckedChangeListener { _, on ->
                    p.edit().putBoolean("on_${s.key}", on).apply()
                    Alarms.schedule(this@MainActivity, s)
                }
            })
            button("%02d:%02d".format(h, m)) {
                TimePickerDialog(this, { _, nh, nm ->
                    p.edit().putInt("h_${s.key}", nh).putInt("m_${s.key}", nm).apply()
                    Alarms.schedule(this, s)
                    settings()
                }, h, m, true).show()
            }
        }
    }
}
