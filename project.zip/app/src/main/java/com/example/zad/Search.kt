package com.example.zad

import android.content.Context

private val MARKS = Regex("[\u0610-\u061a\u064b-\u065f\u0670\u06d6-\u06ed\u0640]")
private val STOP = setOf("في", "من", "على", "عن", "الى", "ما", "هو", "هي", "ان", "او", "ثم", "مع", "هذا", "هذه",
    "اريد", "ابحث", "حديث", "احاديث", "ايه", "ايات", "سوره", "موضوع", "حول", "عند", "كيف", "لي")

// توحيد الكتابة: بلا تشكيل، وتوحيد الهمزات والتاء المربوطة
fun normalize(s: String) = s.replace(MARKS, "")
    .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ٱ', 'ا')
    .replace('ى', 'ي').replace('ة', 'ه')

private fun words(q: String) = normalize(q).split(Regex("\\s+"))
    .map { if (it.length > 4 && it.startsWith("ال")) it.substring(2) else it }
    .filter { it.length > 1 && it !in STOP }

// بحث بالكلمات: الأعلى ترتيبًا ما طابق كلمات أكثر. يُستدعى خارج الخيط الرئيسي
fun search(c: Context, query: String): List<Item> {
    val keys = words(query)
    if (keys.isEmpty()) return emptyList()
    val found = ArrayList<Pair<Item, Int>>()
    fun check(item: Item) {
        val text = normalize(item.text)
        val explain = normalize(item.explain)
        val score = keys.sumOf { k -> (if (k in text) 3 else 0) + (if (k in explain) 2 else 0) }
        if (score > 0) found.add(item to score)
    }
    // اسم سورة منطوق أو مكتوب: نعرض أولها
    val asked = normalize(query).replace("سوره", "").trim()
    val named = SURAS.indexOfFirst { normalize(it) == asked }
    for (s in 1..114) sura(c, s).forEach { check(it) }
    for (cat in listOf("hadith", "qudsi", "dua", "motiv")) items(c, cat).forEach { check(it) }
    val best = found.sortedByDescending { it.second }.map { it.first }.distinctBy { it.text }.take(60)
    return if (named >= 0) sura(c, named + 1).take(10) + best.take(30) else best
}
